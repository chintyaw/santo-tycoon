cara compile di windows:

gcc main.c ADT/graf/graf.c ADT/mesinkata/mesinkata.c ADT/mesinkar/mesinkar.c ADT/matriks/matriks.c ADT/point/point.c ADT/queue/queueM.c ADT/shop.c ADT/array/ListDynCAD.c ADT/stack/stackI.c -o main.exe

mohon maaf di Linux tidak bisa :(